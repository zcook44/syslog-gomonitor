# Operations

## Commands

The installed binary is `/usr/local/bin/syslog-gomonitor`.

| Command | What it does |
| --- | --- |
| `serve` | Run the dashboard, the activity poll, discovery of untracked files, and by default the hourly size pass. |
| `size` | Measure stored size once, write the snapshot, and print a text report. |
| `check` | Print one JSON snapshot. Uses the saved sizes unless `--scan-size` is set. |
| `validate` | Check the inventory and print the watched directories, ignored paths, and resolved device paths. Does not stat logs. |
| `configure` | Save `log_directories` into the inventory. Creates a starter inventory when the file is missing. Keeps existing devices. |
| `demo` | Workstation-only synthetic fleet. Not used on the syslog server. |

`serve` flags:

| Flag | Default | Meaning |
| --- | --- | --- |
| `--config` | `/etc/syslog-gomonitor/devices.json` | Inventory |
| `--state` | `/var/lib/syslog-gomonitor/sizes.json` | Hourly size snapshot |
| `--listen` | `127.0.0.1:8080` | `host:port`. The installed unit uses `0.0.0.0:8443`. |
| `--tls-cert` | none | PEM chain: server certificate, then intermediates. With `--tls-key`, the listener is HTTPS. |
| `--tls-key` | none | Private key for that server certificate. Other users must not be able to read it. |
| `--poll` | `5s` | Activity check interval. Minimum `200ms`. |
| `--size-interval` | `1h` | Stored-size interval. `0s` reads the snapshot and does not scan. |
| `--discover-interval` | `30s` | How often to look for files in `log_directories` that are not in the inventory. `0s` does that once at startup. |

## Dashboard

The page title is "Syslog source monitor". **Browser** is the default color
theme and follows the browser. **Light** and **Dark** override that for the
whole page and keep the choice in this browser. **Browser** clears the override.
Counts at the top are the whole inventory, not the rows left after a filter.
**Back to top** appears after the page is scrolled and returns to the header.

| Card | Click |
| --- | --- |
| Devices | Clear a status filter and show the device table, including when **Not in inventory** or **Ignored** is open. |
| Healthy | Show only healthy devices. |
| Needs attention | Show only devices that need attention. |
| Unknown | Show only unknown devices. |
| Stored logs | Not a filter. Total bytes from successful size measurements. |
| Not in inventory | Shown when `log_directories` is set. Hides the device table and lists one card per untracked directory or loose file. The count is not part of the device total. |
| Ignored | Shown when `log_directories` is set. Hides the device table and lists paths recorded in `ignored`. The count is not part of the device total. |

Clicking a status card that is already selected clears that filter and leaves
no card highlighted. **Devices** also clears a status filter. Selecting **Not
in inventory** or **Ignored** again returns to the device table, as does
selecting any device card. While either list is open, live updates refresh the
device table and the summary counts, and leave that list in place so a form
keeps what was typed. Returning to the device table loads the latest list.
The search box matches the device name, source
address, log path, protocol, reporting state, and overall status. Search and a
status card apply together, and only to the device table. "Showing 2 of 9"
counts rows that pass both. A live update keeps the current search and the
open card.

Columns:

| Column | Source |
| --- | --- |
| Reporting | Current log only. Receiving, Stale, Missing, Empty, or Unknown. |
| Connection | `Connectionless` for UDP. Established, no session, or the `ss` error for TCP. |
| Last write | Modification time of the current file, in UTC. |
| Active file | Size of the file the poll just stated. Updates on every poll. A dated name is the newest day of that series, not the path stored at adoption. |
| Stored logs | Active file plus rotations, from the last hourly measurement. A dated name also includes the other days of that series. |
| Overall | Healthy, Needs attention, or Unknown. |

Rows are ordered with problems first, then unknown, then healthy, and by name
inside each group. The active-file number can move past the stored total
between hourly passes. That is expected: stored size is not recomputed when
the current file grows.

From those two lists:

| Action | Result |
| --- | --- |
| Adopt | Appends the device to `devices.json`. When the card lists more than one log file, the selected convention is the one that is stored. A per-address file keeps the address in its path. A loose file needs a source IP. The new row appears on the next update. A dated name keeps following the newest matching file. |
| Ignore | Adds every log file on the card to `ignored`. Those files are not monitored. A per-address ignore also hides that source address if the file is created again. Ignoring one day of a dated name hides later days of that name. |
| Stop ignoring | Removes the `ignored` entry. The file is offered again when it is still there. |

A successful adopt turns that card green, and a successful ignore turns it amber. The card then leaves the open list. A missing or rejected value stays, with a red border on the card and on the field that needs attention.

The name field is editable until you adopt. A directory with both `syslog.log`
and `messages.log`, or with more than one dated convention, shows a log-file
menu. Days of one dated name are a single choice, labeled with `{date}`, and
the choice points at the newest file. Rotations, `.offset` and `.state`
files, and symlinks are not listed. The list says when a directory could not
be read, or when more than 100 untracked sources were found. `validate` prints
ignored paths. `check` includes `candidates` and `ignored` in the JSON snapshot.

Select a device row, or press Enter on a highlighted row, to open its detail
card. The card shows status, the silence limit, the active path, and every
name in that log directory. **Active** is the file being checked. **Same
series** is another day of a dated name. **Rotation** is a sibling such as
`.1` or `.gz`. Other names, symlinks, and subdirectories are labeled and are
not followed. The card re-reads the directory while it stays open. Close
returns to the table. `GET /api/device?source_ip=` is the same information as
JSON. Log contents are not included.

## How to read a row

| What you see | Usual cause |
| --- | --- |
| Receiving, connectionless, healthy | UDP device wrote its file inside the silence limit. |
| Receiving, established, healthy | TCP device wrote its file and still has a session to the configured port. |
| Stale | The file is non-empty and older than `stale_after_seconds`. A quiet device needs a longer limit or a heartbeat. |
| Missing | The path does not exist yet. |
| Empty | The file exists and has size 0. Rotation often leaves this until the next message. |
| No session | The log may be fresh, but `ss` shows no established connection from that source to `tcp_port`. |
| Established and stale | The TCP session is up and the log has stopped. |
| Unknown log, "not a regular file" | The path is a symlink, directory, or other non-file. Symlinks are not followed. |
| Unknown log, future mtime | The modification time is more than 60 seconds ahead of the server clock. |
| Unknown connection | `ss` is missing, failed, or returned output that could not be parsed. |
| Stored pending | No `sizes.json` entry yet. |
| Stored unavailable | The log directory could not be listed. |

A TCP session to the wrong port does not count. The match is the device's
source IP and the collector's local port.

## Worked checks

Inventory accepted, paths resolved:

```bash
sudo syslog-gomonitor validate --config /etc/syslog-gomonitor/devices.json
```

One JSON snapshot, including the last stored-size time:

```bash
sudo syslog-gomonitor check \
  --config /etc/syslog-gomonitor/devices.json \
  --state /var/lib/syslog-gomonitor/sizes.json
```

Force a size measurement and keep the service's hourly schedule:

```bash
sudo syslog-gomonitor size \
  --config /etc/syslog-gomonitor/devices.json \
  --state /var/lib/syslog-gomonitor/sizes.json
```

Service health:

```bash
systemctl status syslog-gomonitor.service
journalctl -u syslog-gomonitor.service -n 50 --no-pager
curl --fail --cacert /path/to/root.pem https://127.0.0.1:8443/healthz
```

An install that used `--http` answers on loopback without TLS:

```bash
curl --fail http://127.0.0.1:8080/healthz
```

The journal records startup, each hourly measurement, an inventory reload, an
adopt or ignore, and a measurement that could not be saved. It does not
record every 5-second poll or every discovery pass.

## Failure behavior

| Event | Result |
| --- | --- |
| Device log missing | Row needs attention. The service stays up. |
| Inventory edit does not validate | Previous device list keeps running. The error is logged. |
| Adopt or ignore is rejected | The page shows the reason. `devices.json` is unchanged when the new file would not validate. |
| Adopt or ignore cannot replace `devices.json` | The page says the inventory could not be updated. The previous file remains when the replace itself fails. |
| `ss` fails | TCP connections become Unknown. UDP rows are unchanged. |
| Size snapshot cannot be written | The in-memory totals from that pass are still shown. The old file remains. The next pass tries again. |
| Process crash | systemd restarts it after 2 seconds. Activity history is not recovered. `sizes.json` is recovered when it is newer than the interval. |
| Output file `sizes.json` is a symlink | The write is refused. |

## Resources

The poll stats one file per device and, when needed, runs `ss` once. A dated
name also lists that one directory so the newest day can be chosen. It does
not walk rotation trees or read file contents. Opening a device card lists
that directory on demand. The hourly pass lists each distinct log directory
once. That hourly walk is the expensive part, which is why it is not on the
5-second loop.

The optional timer unit runs the size command at a lower CPU and I/O priority
than the dashboard process. Use that split when the log directories are large
enough that you do not want the walk inside the process serving the page.

## Lab

The container lab in [../lab/README.md](../lab/README.md) is the test bed for
monitor changes. A collector container runs rsyslog and a monitor built
from the working tree. More than ten example containers send syslog, and the
collector pins a few files so the page also shows missing, stale, empty,
symlink, and future-mtime rows. It also writes untracked dated logs so **Not
in inventory** has adoption cards for `name-date-syslog.log`. The dashboard
is HTTPS on port 8443, published on the host's addresses. Trust
`lab/tls/out/ca.pem` before opening it.

```bash
docker compose -f lab/compose.yaml up -d --build
```

Rebuild `collector` after a monitor change. That image is the only one that
contains the program.

## Demo, not production

The single-process demo does not run rsyslog. On a workstation with Go:

```bash
go run ./cmd/syslog-gomonitor demo
```

Open `http://127.0.0.1:18082/`. The process creates example logs and two
loopback TCP sessions under a temp directory it prints at startup. It does
not use `/var/log` or the production unit. `--once` writes a single page and
exits. The nine example devices cover receiving, stale, missing, empty,
TCP up, TCP down, TCP silent, a symlink, and a future modification time.
